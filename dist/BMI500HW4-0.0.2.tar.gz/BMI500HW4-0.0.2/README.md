# BMI500_HW4_Packaging
Cluster and Packaging

Timing 0.756 s